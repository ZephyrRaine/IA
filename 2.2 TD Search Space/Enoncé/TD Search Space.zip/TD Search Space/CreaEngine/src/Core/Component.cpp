#include "stdafx.h"

#include "Core\Component.h"

namespace crea
{
	Component::Component()
	{

	}

	Component::~Component()
	{

	}

} // namespace crea
